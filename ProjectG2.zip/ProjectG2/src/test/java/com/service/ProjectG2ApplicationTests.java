package com.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectG2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
